import logging
import cv2
import SunFounder_PiCar.picar as picar
from concurrent.futures import ThreadPoolExecutor
import queue

from models.path_follower import PathFollower
from models.obstacle_avoider import ObstacleAvoider
from models.VFH_obstacle_avoider import VFHObstacleAvoider

_SHOW_IMAGE = False

PORT_NAME = "/dev/ttyUSB0"


class ALVN(object):
    __SCREEN_WIDTH = 640
    __SCREEN_HEIGHT = 480

    def __init__(self):
        """Initialize the ALVN object."""
        logging.info("Creating a PiCar...")

        picar.setup()

        self.initialize_camera()

        self.initialize_pan_tilt_servos()

        self.back_wheels = self.setup_back_wheels()

        self.front_wheels = self.setup_front_wheels()
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.frame_queue = queue.Queue()
        self.path_follower = PathFollower(self, self.executor)
        self.obstacle_avoider = ObstacleAvoider(self)
        self.vfh_obstacle_avoider = VFHObstacleAvoider(self)


    def initialize_camera(self):
        """Initialize the camera."""
        logging.debug("Setting up camera")
        self.camera = cv2.VideoCapture(-1)
        self.camera.set(3, self.__SCREEN_WIDTH)
        self.camera.set(4, self.__SCREEN_HEIGHT)

    def initialize_pan_tilt_servos(self):
        """Initialize the pan and tilt servos."""
        self.pan_servo = picar.Servo.Servo(1)
        self.pan_servo.offset = 5 # calibrate camera pan servo to center
        self.pan_servo.write(90)

        self.tilt_servo = picar.Servo.Servo(2)
        self.tilt_servo.offset = -30  # calibrate camera tilt servo to down
        self.tilt_servo.write(80)

    def setup_back_wheels(self):
        """Set up the back wheels."""
        logging.debug("Set up back wheels")
        back_wheels = picar.back_wheels.Back_Wheels()
        back_wheels.calibration()
        back_wheels.cali_ok()
        back_wheels.ready()
        back_wheels.speed = 0
        return back_wheels

    def setup_front_wheels(self):
        """Set up the front wheels."""
        logging.debug("Set up front wheels")
        front_wheels = picar.front_wheels.Front_Wheels()
        front_wheels.turning_offset = 0
        front_wheels.turn(90)
        return front_wheels

    def __enter__(self):
        """Entering a with statement."""
        return self

    def __exit__(self, _type, value, traceback):
        if traceback is not None:
            logging.error("Exiting with statement with exception %s" % traceback)
            self.cleanup()

    def cleanup(self):
        """Reset the hardware."""
        logging.info("Stopping the car, resetting hardware.")
        self.back_wheels.speed = 0
        self.front_wheels.turn(90)
        self.camera.release()
        cv2.destroyAllWindows()

    def drive_obstacles(self, speed, type):
        """Drive the car with obstacle avoidance."""
        logging.info(
            "Beginning to drive with obstacle avoidance at speed %s..." % speed
        )
        self.back_wheels.speed = speed
        if type == 1:
            self.obstacle_avoider.drive(speed)
        if type == 2:
            self.vfh_obstacle_avoider.drive(speed)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            self.cleanup()


    def drive_path(self, speed):
        logging.info("Beginning to drive with path following at speed %s..." % speed)
        self.back_wheels.speed = speed
        
        if not self.camera.isOpened():
            raise Exception("Could not open video device")
            
        while self.camera.isOpened():
            _, image_lane = self.camera.read()
            self.frame_queue.put(image_lane)

            if not self.frame_queue.empty():
                image_lane = self.frame_queue.get()
                image_lane = self.executor.submit(self.follow_path, image_lane).result()

            show_image("Path Line", image_lane)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                self.cleanup()
                return


    def follow_path(self, image):
        image = self.path_follower.follow_path(image)
        return image


def show_image(title, frame, show=_SHOW_IMAGE):
    if show:
        cv2.imshow(title, frame)
