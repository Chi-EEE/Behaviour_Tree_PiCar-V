import cv2
import numpy as np

class PathFollower:
    def __init__(self, car, executor):
        self.car = car
        self.executor = executor
        self.buffer_size = 3
        self.steering_angles = []
        self.max_steering_delta = 20
        self.scaling_factor = 0.1

    def preprocess_image(self, img):
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        lower_black = np.array([0, 0, 0])
        upper_black = np.array([180, 255, 80])

        mask = cv2.inRange(hsv, lower_black, upper_black)
        return mask


    def detect_lines(self, thresholded_img):
        rho = 1
        theta = np.pi / 180
        threshold = 50
        min_line_length = 20
        max_line_gap = 30

        lines = cv2.HoughLinesP(
            thresholded_img, rho, theta, threshold, np.array([]), min_line_length, max_line_gap
        )

        return lines

    def average_slope_intercept(self, lines):
        left_lines = []
        right_lines = []

        if lines is None:
            return None, None

        for line in lines:
            for x1, y1, x2, y2 in line:
                if x1 == x2:
                    continue

                slope = (y2 - y1) / (x2 - x1)
                intercept = y1 - slope * x1
                if slope < 0:
                    left_lines.append((slope, intercept))
                else:
                    right_lines.append((slope, intercept))

        left_lane = np.mean(left_lines, axis=0) if left_lines else None
        right_lane = np.mean(right_lines, axis=0) if right_lines else None

        return left_lane, right_lane


    def make_line_points(self, y1, y2, line):
        if line is None:
            return None

        slope, intercept = line

        # Check for infinite slopes and handle them
        if np.isinf(slope):
            if np.isinf(intercept):
                return None
            x1 = x2 = int(intercept)
        else:
            x1 = int((y1 - intercept) / (slope + 1e-8 ))
            x2 = int((y2 - intercept) / (slope + 1e-8 ))

        return (x1, y1), (x2, y2)



    def find_line_center(self, left_line, right_line):
        if left_line is None or right_line is None:
            return 0, 0

        (left_x1, left_y1), (left_x2, left_y2) = left_line
        (right_x1, right_y1), (right_x2, right_y2) = right_line

        left_cx = (left_x1 + left_x2) // 2
        left_cy = (left_y1 + left_y2) // 2

        right_cx = (right_x1 + right_x2) // 2
        right_cy = (right_y1 + right_y2) // 2

        cx = (left_cx + right_cx) // 2
        cy = (left_cy + right_cy) // 2

        return cx, cy


    def draw_center(self, img, cx, cy):
        cx, cy = self.clip_coordinates(img, cx, cy)
        cv2.circle(img, (cx, cy), 5, (0, 255, 0), -1)

    def draw_lines(self, img, left_line, right_line, color=(0, 255, 0), thickness=5):
        left_line = self.clip_line_coordinates(img, left_line)
        right_line = self.clip_line_coordinates(img, right_line)

        if left_line is not None:
            cv2.line(img, left_line[0], left_line[1], color, thickness)
        if right_line is not None:
            cv2.line(img, right_line[0], right_line[1], color, thickness)


    def follow_path(self, image):
        image_copy = image.copy()
        thresholded_img_future = self.executor.submit(self.preprocess_image, image)
        thresholded_img = thresholded_img_future.result()
        lines_future = self.executor.submit(self.detect_lines, thresholded_img)
        lines = lines_future.result()

        left_lane, right_lane = self.average_slope_intercept(lines)

        if left_lane is None and right_lane is None:
            return image_copy

        y1 = thresholded_img.shape[0]
        y2 = int(y1 * 0.6)

        left_line = self.make_line_points(y1, y2, left_lane)
        right_line = self.make_line_points(y1, y2, right_lane)

        if left_line is not None and right_line is not None:
            cx, cy = self.find_line_center(left_line, right_line)
            self.draw_center(image_copy, cx, cy)
        else:
            cx, cy = 0, 0

        self.draw_lines(image_copy, left_line, right_line)

        offset = cx - thresholded_img.shape[1] // 2
        steering_angle = self.calculate_steering_angle(offset)

        if self.steering_angles:
            last_angle = self.steering_angles[-1]
            steering_angle = np.clip(
                steering_angle,
                last_angle - self.max_steering_delta,
                last_angle + self.max_steering_delta,
            )

        self.steering_angles.append(steering_angle)
        if len(self.steering_angles) > self.buffer_size:
            self.steering_angles.pop(0)
        smoothed_angle = sum(self.steering_angles) / len(self.steering_angles)

        self.car.front_wheels.turn(smoothed_angle)
        print(f"Steering angle: {smoothed_angle:.2f}°")
        self.show_image("Path Follower ", image_copy)

        return image_copy


    def clip_coordinates(self, img, cx, cy):
        max_x = img.shape[1] - 1
        max_y = img.shape[0] - 1

        cx = np.clip(cx, 0, max_x)
        cy = np.clip(cy, 0, max_y)

        return cx, cy

    def clip_line_coordinates(self, img, line):
        if line is None:
            return None

        (x1, y1), (x2, y2) = line
        x1, y1 = self.clip_coordinates(img, x1, y1)
        x2, y2 = self.clip_coordinates(img, x2, y2)

        return (x1, y1), (x2, y2)


    def calculate_steering_angle(self, offset):
        max_angle = 135
        min_angle = 45
        center_angle = 90

        angle = center_angle - offset * self.scaling_factor
        angle = np.clip(angle, min_angle, max_angle)

        return angle

    def show_image(self, window_name, image):
        cv2.imshow(window_name, image)
        cv2.waitKey(1)
