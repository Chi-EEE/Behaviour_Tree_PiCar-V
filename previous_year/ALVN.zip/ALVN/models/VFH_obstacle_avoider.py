import logging
from rplidar import RPLidar, RPLidarException
import time
import collections
import numpy as np
from time import sleep
from serial.serialutil import PortNotOpenError

PORT_NAME = "/dev/ttyUSB0"
lidar = RPLidar(PORT_NAME)
logging.basicConfig(level=logging.INFO)

class VFHObstacleAvoider(object):
    def __init__(self, car=None):
        """Initialize VFHObstacleAvoider with a car object."""
        logging.info("Initialising VFHObstacleAvoider...")
        self.car = car
        self.curr_steering_angle = 90
        self.window_size = 5
        self.angle_buffer = collections.deque(maxlen=self.window_size)
        self.max_steering_change = 40
        self.update_rate = 0.6
        self.speed = 0
        self.num_sectors = 5
        self.min_angle = 30
        self.max_angle = 150
        self.min_distance_threshold = 120
        self.cell_resolution = 2
        self.histogram_threshold = 6
        self.vfh_max_angle = 40

    def drive(self, speed):
        """Drive the car using lidar obstacle avoidance."""
        logging.info(f"Beginning to drive with obstacle avoidance at speed {speed}...")
        self.speed = speed

        while True:
            try:
                continue_avoiding = True
                while continue_avoiding:
                    try:
                        for measurement in lidar.iter_scans(max_buf_meas=5000):
                            # Apply VFH algorithm to calculate the target angle
                            target_angle = self.calculate_vfh_target_angle(measurement)
                            self.steer(target_angle)

                            # Check if the closest obstacle is too close
                            if min(self.get_distances_within_angle_range(measurement, self.min_angle, self.max_angle)) < self.min_distance_threshold:
                                logging.info("Obstacle too close, stopping the car")
                                break

                            else:
                                continue_avoiding = False
                        self.car.back_wheels.speed = self.speed

                    except RPLidarException as e:
                        if str(e) == "Incorrect descriptor starting bytes":
                            logging.warning("Incorrect descriptor starting bytes. Restarting the lidar device and trying again...")
                            lidar.stop()
                            lidar.stop_motor()
                            lidar.disconnect()
                            sleep(1)
                            lidar.connect()
                            lidar.start_motor()
                        if str(e) == "Check bit not equal to 1":
                            logging.warning("Check bit not equal to 1 Restarting the lidar device and trying again...")
                            lidar.stop()
                            lidar.stop_motor()
                            lidar.disconnect()
                            sleep(1)
                            lidar.connect()
                            lidar.start_motor()
                        else:
                            raise e

                break

            except KeyboardInterrupt:
                print("Keyboard Interrupt, Stopping the car")
                break

            except PortNotOpenError:
                print("Port not open, waiting and trying again")
                time.sleep(2)  # Wait for 2 seconds before trying again

            except Exception as e:
                print(f"Stopping the car because of an error: {e}")
                break

            finally:
                self.cleanup()

    def steer(self, angle):
        """Steer the car based on the given angle."""
        if self.car is not None:
            inverted_angle = 90 - (
                angle - 90
            )  # Invert the angle with respect to 90 degrees
            angle_diff = inverted_angle - self.curr_steering_angle
            clamped_diff = np.clip(
                angle_diff, -self.max_steering_change, self.max_steering_change
            )
            new_steering_angle = (
                self.curr_steering_angle + clamped_diff * self.update_rate
            )
            self.curr_steering_angle = new_steering_angle
            self.car.front_wheels.turn(self.curr_steering_angle)
            logging.info(
                f"Steering to {self.curr_steering_angle} degrees (angle: {angle})"
            )

    
    def calculate_vfh_target_angle(self, measurement):
        """Calculate the target angle using the VFH algorithm."""
        histogram = self.build_histogram(measurement)
        candidate_angles = self.select_candidate_angles(histogram)
        return self.choose_best_angle(candidate_angles)

    def build_histogram(self, measurement):
        """Build a histogram based on lidar measurements."""
        histogram = np.zeros(360)

        for m in measurement:
            if m[0] > 0:
                angle = int(m[1])
                distance = m[2]

                cell_size = int(distance / self.cell_resolution)
                for i in range(angle - cell_size, angle + cell_size + 1):
                                index = i % 360
                                histogram[index] += 1

        return histogram

    def select_candidate_angles(self, histogram):
        """Select candidate angles from the histogram."""
        candidate_angles = []

        for i in range(self.min_angle, self.max_angle + 1):
            if histogram[i] < self.histogram_threshold:
                candidate_angles.append(i)

        logging.info(f"Candidate angles: {candidate_angles}")
        return candidate_angles

    def choose_best_angle(self, candidate_angles):
        """Choose the best angle from the candidate angles."""
        if len(candidate_angles) == 0:
            return self.curr_steering_angle

        best_angle = candidate_angles[0]
        min_diff = abs(candidate_angles[0] - self.curr_steering_angle)

        for angle in candidate_angles:
            diff = abs(angle - self.curr_steering_angle)
            if diff < min_diff:
                min_diff = diff
                best_angle = angle

        # Limit steering angle change to vfh_max_angle
        angle_diff = best_angle - self.curr_steering_angle
        clamped_diff = np.clip(angle_diff, -self.vfh_max_angle, self.vfh_max_angle)
        best_angle = self.curr_steering_angle + clamped_diff

        return best_angle

    def get_distances_within_angle_range(self, measurement, min_angle, max_angle):
        """Get distances of the obstacles within the specified angle range."""
        distances = []

        for m in measurement:
            if min_angle <= m[1] <= max_angle and m[0] > 0:
                distances.append(m[2])

        if not distances:
            # If the list is empty, add a large value to avoid the min() error
            distances.append(float("inf"))

        return distances


    def cleanup(self):
        """Reset the hardware."""
        logging.info("Stopping the car, resetting hardware.")
        self.car.back_wheels.speed = 0
        self.car.front_wheels.turn(90)
        lidar.stop()
        lidar.stop_motor()
        lidar.disconnect()
    
    def clear():
        print("\033c", end="") 
