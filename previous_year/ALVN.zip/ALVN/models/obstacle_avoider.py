import logging
from rplidar import RPLidar, RPLidarException
from serial.serialutil import PortNotOpenError
import collections
import numpy as np
from time import sleep

PORT_NAME = "/dev/ttyUSB0"
lidar = RPLidar(PORT_NAME)
logging.basicConfig(level=logging.INFO)


class ObstacleAvoider(object):
    def __init__(self, car=None):
        logging.info("Initialising ObstacleAvoider...")
        self.car = car
        self.curr_steering_angle = 90
        self.window_size = 3
        self.angle_buffer = collections.deque(maxlen=self.window_size)
        self.max_steering_change = 55
        self.update_rate = 0.5
        self.speed = 0

    def drive(self, speed):
        """Drive the car forward while avoiding obstacles."""
        logging.info("Driving...")
        num_sectors = 7
        min_angle = 40
        max_angle = 140
        min_distance_threshold = 270
        self.speed = speed

        continue_avoiding = True

        while continue_avoiding:
            try:
                for measurement in lidar.iter_scans():
                    sector_distances = self.get_sector_distances(
                        measurement, num_sectors, min_angle, max_angle
                    )
                    self.print_visualization(sector_distances)
                    min_distance_sector = np.argmin(sector_distances)
                    target_angle = (
                        min_angle
                        + (min_distance_sector + 0.5)
                        * (max_angle - min_angle)
                        / num_sectors
                    )
                    self.steer(target_angle)

                    front_sector_index = num_sectors // 2
                    front_distance = sector_distances[front_sector_index]

                    # Check if the closest obstacle is too close and in front
                    if 0 < front_distance < min_distance_threshold:
                        logging.info("Obstacle too close and in front, performing emergency maneuver")
                        # self.emergency_maneuver()
                        self.car.back_wheels.speed = 0
                    else:
                        self.car.back_wheels.speed = self.speed
                        
                self.car.back_wheels.speed = self.speed
                
            except RPLidarException as e:
                logging.warning("Incorrect descriptor starting bytes. Restarting the lidar device and trying again...")
                lidar.stop()
                lidar.stop_motor()
                lidar.disconnect()
                sleep(1)
                lidar.connect(PORT_NAME)
                lidar.start_motor()
                continue

            except KeyboardInterrupt:
                print("Keyboard Interrupt, Stopping the car")
                break

            except PortNotOpenError:
                logging.warning("Port Not Open Error, trying again...")
                lidar.stop()
                lidar.stop_motor()
                lidar.disconnect()
                sleep(1)
                lidar.connect(PORT_NAME)
                lidar.start_motor()
                continue

            except Exception as e:
                print(f"Stopping the car because of an error: {e}")
                break

            finally:
                self.cleanup()

        self.cleanup()

    def steer(self, angle):
        """Steer the car towards the target angle."""
        if self.car is not None:
            inverted_angle = 90 - (
                angle - 90
            )  # Invert the angle with respect to 90 degrees
            angle_diff = inverted_angle - self.curr_steering_angle
            clamped_diff = np.clip(
                angle_diff, -self.max_steering_change, self.max_steering_change
            )
            new_steering_angle = (
                self.curr_steering_angle + clamped_diff * self.update_rate
            )
            self.curr_steering_angle = new_steering_angle
            self.car.front_wheels.turn(self.curr_steering_angle)
            logging.info(
                f"Steering to {self.curr_steering_angle} degrees (angle: {angle}"
            )

    def emergency_maneuver(self):
        """Perform emergency maneuver when an obstacle is too close."""
        logging.info("Emergency maneuver initiated")
        # Stop the car
        self.car.back_wheels.speed = 0
        sleep(1)
        
        # Reverse the car to a safe distance
        self.car.back_wheels.backward()
        self.car.back_wheels.speed = self.speed
        sleep(2)

        # Stop the car
        self.car.back_wheels.speed = 0
        sleep(1)

        # Continue driving forward
        self.car.back_wheels.forward()
        self.car.back_wheels.speed = self.speed
        logging.info("Emergency maneuver complete, resuming forward movement")


    def get_sector_distances(self, measurement, num_sectors, min_angle, max_angle):
        """ Get the distances for each sector from the measurements. """
        sector_size = (max_angle - min_angle) / num_sectors
        sector_distances = np.zeros(num_sectors)
        sector_counts = np.zeros(num_sectors)

        valid_measurements = np.array(
            [m for m in measurement if min_angle <= m[1] <= max_angle and m[0] > 0]
        )

        if len(valid_measurements) > 0:
            angles = valid_measurements[:, 1]
            distances = valid_measurements[:, 2]
            sector_indices = ((angles - min_angle) / sector_size).astype(int)
            sector_indices = np.clip(sector_indices, 0, num_sectors - 1)

            np.add.at(sector_distances, sector_indices, distances)
            np.add.at(sector_counts, sector_indices, 1)
            sector_distances /= np.maximum(sector_counts, 1)

        return sector_distances

    def cleanup(self):
        """Reset the hardware."""
        logging.info("Stopping the car, resetting hardware.")
        if self.car is not None:
            self.car.back_wheels.speed = 0
            self.car.front_wheels.turn(90)
        lidar.stop()
        lidar.stop_motor()
        lidar.disconnect()

    def print_visualization(self, sector_distances):
        """Print a simple text-based visualization of the LIDAR measurements and the current steering angle."""
        print("\033c")
        print("Sector Distances:")
        for i, distance in enumerate(sector_distances):
            print(f"Sector {i+1}: {distance:.2f} cm")

        print(f"Current Steering Angle: {self.curr_steering_angle:.2f}°")
        print("=" * 40)
