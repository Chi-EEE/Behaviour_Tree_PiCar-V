# ALVN: Autonomous Lidar and Vision-based Navigator

ALVN is a project aimed at developing an autonomous navigation system for a vehicle, using image processing and LiDAR spatial mapping. It is intended to be a final year project for the SETU Software Development course.

## Installation
### IMPORTANT!
The SunFounder PiCar module has been added to this repository as a submodule.
It is important to use the command below to properly clone this repo and the SunFounder_PiCar submodule along with it.

Clone this repository to your Raspberry Pi.
```
git clone --recurse-submodules --remote-submodules https://github.com/monc949/ALVN.git
```
Install the required software packages using pip:

```
pip3 install opencv-python numpy rplidar
```


Follow the instructions provided by Sunfounder to assemble the PiCar-V kit.

Connect the Slamtec RPLidar A2M8 sensor and the camera to the Raspberry Pi, following their respective documentation.

Run the app.py script to start the application.

## Hardware Requirements

Sunfounder PiCar-V

Slamtec RPLidar A2M8 sensor

## Software Requirements

Raspberry Pi OS

Python 3

OpenCV

Numpy

RPLidar library


## Usage

Upon running the app.py script, a command-line interface (CLI) menu will be displayed with 6 options:

1. Follow a path

2. Follow lanes

3. Avoid obstacles

4. Follow path and avoid obstacles (Not Implemented Yet)

5. Follow lanes and avoid obstacles (Not Implemented Yet)

6. Reset Hardware

7. Quit

Selecting an option will start the corresponding function, and the car will begin navigating according to the chosen algorithm. The user does not need to provide any input during runtime.

The car can be stopped by interrupting the program with a keyboard interrupt (Ctrl+C).

## Contributors

Ciaran Maye

Dr. Oisin Cawley
