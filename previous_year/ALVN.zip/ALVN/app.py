import os
from time import sleep
from models.alvn import ALVN
import logging
import sys


def print_menu():
    os.system("clear")

    print("ALVN Menu")
    print("==========")
    print("Select an option:")
    print("1. Follow a path")
    print("2. Avoid obstacles")
    print("3. Follow path and avoid obstacles")
    print("4. Reset hardware")
    print("5. Quit")
    print()


def get_speed():
    while True:
        try:
            speed = int(input("Enter speed (0-100): "))
            if 0 <= speed <= 100:
                return speed
            else:
                print("Invalid input. Speed must be between 0 and 100.")
        except ValueError:
            print("Invalid input. Please enter a number between 0 and 100.")

def get_obstacle_avoider_type():
    while True:
        try:
            print("1. Polar")
            print("2. VFH")
            type = int(input("Enter obstacle avoider type (1-2): "))
            if 1 <= type <= 2:
                return type
            else:
                print("Invalid input. Type must be between 1 and 2.")
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 2.")

def reset_hardware(car):
    car.cleanup()
    sleep(1)
    print("Hardware reset completed.")
    sleep(2)


def handle_choice(car, choice):
    if choice == 1:
        car.drive_path(get_speed())
    elif choice == 2:
        type = get_obstacle_avoider_type()
        car.drive_obstacles(get_speed(), type)
    elif choice == 3:
        print("Not implemented yet :(")
    elif choice == 4:
        reset_hardware(car)
    elif choice == 5:
        print("Exiting...")
        car.cleanup()
        return False
    else:
        print("Invalid choice. Please try again.\n")
        sleep(2)
        return True

    return True


def main():
    logging.info(f"Starting ALVN, system info: {sys.version}")
    sleep(1)

    with ALVN() as car:
        while True:
            print_menu()

            try:
                choice = int(input("Enter your choice (1-5): "))
            except ValueError:
                print("Invalid input. Please enter a number between 1 and 5.\n")
                sleep(2)
                continue

            should_continue = handle_choice(car, choice)
            if not should_continue:
                break


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    main()
